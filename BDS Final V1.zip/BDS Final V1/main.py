import subprocess

def run_another_program():
    try:
        # Replace 'python_script.py' with the name of the Python script you want to run
        subprocess.run(['python', 'Install.py'], check=True)
        print("Another Python program executed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    
    run_another_program()
